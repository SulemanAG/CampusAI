const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const path = require('path');
const { db, Collections, MongoDBHelper } = require('./mongodb');

/**
 * STUDENT MANAGEMENT ROUTES
 *
 * REGISTRATION FLOW (2 APIs, EMAIL-BASED):
 * =======================================
 * 1. PARTIAL REGISTRATION (/register/initiate):
 *    - Student provides: email, password
 *    - System verifies: email extension matches a university's studentEmailExtension
 *    - System creates pending registration (keyed by email)
 *    - System returns: university info + list of NON-PRIMARY accounts
 *
 * 2. COMPLETE REGISTRATION (/register/complete):
 *    - Student provides: email, name, selectedNonPrimaryAccountEmail
 *    - System:
 *        * Loads pending registration by email
 *        * Validates selected account belongs to same university & is non-primary
 *        * Gives access to:
 *            - ALL PRIMARY account stores
 *            - SELECTED NON-PRIMARY account store
 */

// Database paths (legacy - kept for reference)
const DB_DIR = path.join(__dirname, 'database');
const STUDENTS_DIR = path.join(DB_DIR, 'students');
const UNIVERSITIES_DIR = path.join(DB_DIR, 'universities');
const ACCOUNTS_DIR = path.join(DB_DIR, 'accounts');
const PENDING_STUDENT_REG_FILE = path.join(DB_DIR, 'pending_student_registrations.json');
const TICKETS_DIR = path.join(DB_DIR, "tickets");

// No need to initialize directories with Firestore
// Firestore collections are created automatically

// Helper: Read pending student registrations
const readPendingStudentRegistrations = async () => {
    try {
        const doc = await MongoDBHelper.getDoc(Collections.PENDING_STUDENT_REGISTRATIONS, 'registry');
        return doc?.registrations || [];
    } catch (error) {
        return [];
    }
};

// Helper: Write pending student registrations
const writePendingStudentRegistrations = async (registrations) => {
    await MongoDBHelper.setDoc(Collections.PENDING_STUDENT_REGISTRATIONS, 'registry', {
        registrations,
        updatedAt: new Date().toISOString()
    });
};

// Helper: Read student data
const readStudent = async (email) => {
    try {
        const sanitizedEmail = MongoDBHelper.sanitizeEmail(email);
        return await MongoDBHelper.getDoc(Collections.STUDENTS, sanitizedEmail);
    } catch (error) {
        return null;
    }
};

// Helper: Write student data
const writeStudent = async (email, studentData) => {
    const sanitizedEmail = MongoDBHelper.sanitizeEmail(email);
    await MongoDBHelper.setDoc(Collections.STUDENTS, sanitizedEmail, studentData);
};

// Helper: Check if student exists
const studentExists = async (email) => {
    const sanitizedEmail = MongoDBHelper.sanitizeEmail(email);
    return await MongoDBHelper.docExists(Collections.STUDENTS, sanitizedEmail);
};

// Helper: Find university by email extension
const findUniversityByEmailExtension = async (studentEmail) => {
    try {
        const emailParts = studentEmail.split('@');
        if (emailParts.length !== 2) return null;

        const emailExtension = `@${emailParts[1]}`;
        
        // Query universities by studentEmailExtension
        const universities = await MongoDBHelper.queryDocs(Collections.UNIVERSITIES, [
            ['studentEmailExtension', '==', emailExtension]
        ]);

        return universities.length > 0 ? universities[0] : null;
    } catch (error) {
        console.error('Error finding university:', error);
        return null;
    }
};

// Helper: Get all accounts for a university
const getUniversityAccounts = async (universityEmail) => {
    try {
        return await MongoDBHelper.queryDocs(Collections.ACCOUNTS, [
            ['universityEmail', '==', universityEmail]
        ]);
    } catch (error) {
        console.error('Error getting university accounts:', error);
        return [];
    }
};

// Helper: Read account data
const readAccount = async (email) => {
    try {
        const sanitizedEmail = MongoDBHelper.sanitizeEmail(email);
        return await MongoDBHelper.getDoc(Collections.ACCOUNTS, sanitizedEmail);
    } catch (error) {
        return null;
    }
};

// Helper: Write ticket
const writeTicket = async (ticketId, data) => {
    await MongoDBHelper.setDoc(Collections.TICKETS, ticketId, data);
};

// Helper: Read all tickets for a student
const getTicketsByEmail = async (email) => {
    try {
        return await MongoDBHelper.queryDocs(Collections.TICKETS, [
            ['studentEmail', '==', email]
        ]);
    } catch (error) {
        console.error('Error getting tickets:', error);
        return [];
    }
};

// ============================================
// STUDENT REGISTRATION APIs (GET VERSION)
// ============================================

// API 1: Initiate Student Registration (GET)
router.get('/register/initiate', async (req, res) => {
    try {
        const { email, password } = req.query;

        // Validation
        if (!email || !password) {
            return res.status(400).json({ error: 'Email and password are required' });
        }

        // Email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return res.status(400).json({ error: 'Invalid email format' });
        }

        // Password strength validation
        if (password.length < 8) {
            return res.status(400).json({ error: 'Password must be at least 8 characters long' });
        }

        // Check if student already exists
        const exists = await studentExists(email);
        if (exists) {
            return res.status(409).json({ error: 'Student email already registered' });
        }

        // Check if pending registration exists (by email only)
        const pendingRegistrations = await readPendingStudentRegistrations();
        const existingPending = pendingRegistrations.find(reg => reg.email === email);
        if (existingPending) {
            return res.status(409).json({
                error: 'Registration already in progress for this email',
                email,
                universityName: existingPending.universityName
            });
        }

        // Find university by email extension
        const university = await findUniversityByEmailExtension(email);
        if (!university) {
            return res.status(404).json({
                error: 'No university found for this email domain. Please check your email address.'
            });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create pending registration (NO registrationId)
        const newRegistration = {
            email,
            password: hashedPassword,
            universityEmail: university.email,
            universityName: university.universityName,
            createdAt: new Date().toISOString(),
            expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // 24 hours
        };

        pendingRegistrations.push(newRegistration);
        await writePendingStudentRegistrations(pendingRegistrations);

        // Get all accounts for the university and return NON-PRIMARY accounts
        const allAccounts = await getUniversityAccounts(university.email);
        const nonPrimaryAccounts = allAccounts
            .filter(account => !account.isPrimary && account.isActive)
            .map(account => ({
                accountEmail: account.accountEmail,
                accountName: account.accountName,
                storeName: account.ragStore?.storeName
            }));

        res.status(201).json({
            message: 'Partial registration successful. Please select one non-primary account to complete registration.',
            email,
            universityName: university.universityName,
            universityEmail: university.email,
            nonPrimaryAccounts
        });
    } catch (error) {
        console.error('Student registration initiation error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});



// API 2: Complete Student Registration (GET)
router.get('/register/complete', async (req, res) => {
    try {
        const {
            email,
            name,
            selectedNonPrimaryAccountEmail
        } = req.query;

        // Validation
        if (!email || !name || !selectedNonPrimaryAccountEmail) {
            return res.status(400).json({
                error: 'email, name, and selectedNonPrimaryAccountEmail are required'
            });
        }

        // Find pending registration (by email only)
        const pendingRegistrations = await readPendingStudentRegistrations();
        const pendingIndex = pendingRegistrations.findIndex(
            reg => reg.email === email
        );

        if (pendingIndex === -1) {
            return res.status(404).json({ error: 'Invalid or expired registration' });
        }

        const pendingReg = pendingRegistrations[pendingIndex];

        // Check if registration has expired
        if (new Date() > new Date(pendingReg.expiresAt)) {
            pendingRegistrations.splice(pendingIndex, 1);
            await writePendingStudentRegistrations(pendingRegistrations);
            return res.status(410).json({ error: 'Registration session expired. Please start again.' });
        }

        // Verify selected non-primary account exists and belongs to the university
        const selectedAccount = await readAccount(selectedNonPrimaryAccountEmail);
        if (!selectedAccount) {
            return res.status(404).json({ error: 'Selected account not found' });
        }

        if (selectedAccount.universityEmail !== pendingReg.universityEmail) {
            return res.status(403).json({
                error: 'Selected account does not belong to your university'
            });
        }

        if (selectedAccount.isPrimary) {
            return res.status(400).json({
                error: 'You can only select non-primary accounts'
            });
        }

        // Get all accounts for the university
        const allAccounts = await getUniversityAccounts(pendingReg.universityEmail);

        // Build accessible stores list
        const accessibleStores = [];

        // Add all PRIMARY account stores
        allAccounts
            .filter(account => account.isPrimary && account.isActive)
            .forEach(account => {
                accessibleStores.push({
                    storeName: account.ragStore?.storeName,
                    storeResource: account.ragStore?.storeResource,
                    accountEmail: account.accountEmail
                });
            });

        // Add selected non-primary
        accessibleStores.push({
            storeName: selectedAccount.ragStore?.storeName,
            storeResource: selectedAccount.ragStore?.storeResource,
            accountEmail: selectedAccount.accountEmail
        });

        // Create student record
        const studentId = `stu_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const student = {
            studentId,
            email: pendingReg.email,
            password: pendingReg.password,
            name,
            universityEmail: pendingReg.universityEmail,
            universityName: pendingReg.universityName,
            selectedNonPrimaryAccount: {
                accountId: selectedAccount.accountId,
                accountEmail: selectedAccount.accountEmail,
                accountName: selectedAccount.accountName
            },
            accessibleStores,
            isActive: true,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };

        // Save to database
        await writeStudent(pendingReg.email, student);

        // Remove from pending registrations
        pendingRegistrations.splice(pendingIndex, 1);
        await writePendingStudentRegistrations(pendingRegistrations);

        // Return response without password
        const { password, ...studentResponse } = student;

        res.status(201).json({
            message: 'Student registration completed successfully',
            studentId,
            student: studentResponse
        });
    } catch (error) {
        console.error('Student registration completion error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// ============================================
// STUDENT LOGIN & PROFILE APIs (GET VERSION)
// ============================================

// API 3: Student Login (GET)
router.get('/login', async (req, res) => {
    try {
        const { email, password } = req.query;

        if (!email || !password) {
            return res.status(400).json({ error: 'Email and password are required' });
        }

        // Find student
        const student = await readStudent(email);
        if (!student) {
            return res.status(401).json({ error: 'Invalid email or password' });
        }

        // Verify password
        const isValidPassword = await bcrypt.compare(password, student.password);
        if (!isValidPassword) {
            return res.status(401).json({ error: 'Invalid email or password' });
        }

        // Check if account is active
        if (!student.isActive) {
            return res.status(403).json({ error: 'Account is deactivated' });
        }

        // Return response without password
        const { password: _, ...studentData } = student;

        res.json({
            message: 'Student login successful',
            student: studentData
        });
    } catch (error) {
        console.error('Student login error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// API 4: Get Student Profile (GET)
router.get('/profile/:email', async (req, res) => {
    try {
        const { email } = req.params;

        const student = await readStudent(email);
        if (!student) {
            return res.status(404).json({ error: 'Student not found' });
        }

        // Return student data without password
        const { password, ...studentData } = student;
        res.json(studentData);
    } catch (error) {
        console.error('Get student profile error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// API 5: Get Accessible Accounts (GET)
router.get('/accessible-accounts/:email', async (req, res) => {
    try {
        const { email } = req.params;

        const student = await readStudent(email);
        if (!student) {
            return res.status(404).json({ error: 'Student not found' });
        }

        // Get all accounts to map store names back to account info
        const allAccounts = await getUniversityAccounts(student.universityEmail);

        const accounts = [];

        // Map each store to its account information
        for (const store of student.accessibleStores) {
            const account = allAccounts.find(acc => acc.ragStore?.storeName === store.storeName);
            if (account) {
                accounts.push({
                    accountName: account.accountName,
                    accountEmail: account.accountEmail
                });
            }
        }

        res.json({
            studentEmail: student.email,
            studentName: student.name,
            universityName: student.universityName,
            totalAccessibleAccounts: accounts.length,
            accounts
        });
    } catch (error) {
        console.error('Get accessible accounts error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// API 6: Get All Accessible Store Names (GET)
router.get('/accessible-stores/:email', async (req, res) => {
    try {
        const { email } = req.params;

        const student = await readStudent(email);
        if (!student) {
            return res.status(404).json({ error: 'Student not found' });
        }

        // Return store names only
        const storeNames = student.accessibleStores.map(store => store.storeName);

        res.json({
            studentEmail: student.email,
            universityName: student.universityName,
            totalStores: storeNames.length,
            storeNames
        });
    } catch (error) {
        console.error('Get accessible stores error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// API 7: Update Student Profile (GET)
router.get('/profile/update', async (req, res) => {
    try {
        const { email, ...updates } = req.query;

        if (!email) {
            return res.status(400).json({ error: 'Email is required' });
        }

        const student = await readStudent(email);
        if (!student) {
            return res.status(404).json({ error: 'Student not found' });
        }

        // Fields that cannot be updated
        const protectedFields = [
            'studentId',
            'email',
            'password',
            'universityEmail',
            'universityName',
            'selectedNonPrimaryAccount',
            'accessibleStores',
            'createdAt'
        ];

        // Remove protected fields from updates
        protectedFields.forEach(field => {
            if (field in updates) delete updates[field];
        });

        // Parse boolean field
        if (updates.isActive !== undefined) {
            updates.isActive = updates.isActive === 'true';
        }

        // Update student
        Object.assign(student, updates, { updatedAt: new Date().toISOString() });

        // Save updated data
        await writeStudent(email, student);

        const { password, ...studentData } = student;
        res.json({
            message: 'Student profile updated successfully',
            student: studentData
        });
    } catch (error) {
        console.error('Update student profile error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// API 8: Get All Students for a University (GET)
router.get('/university/:universityEmail', async (req, res) => {
    try {
        const { universityEmail } = req.params;

        // Query students by universityEmail
        const allStudents = await MongoDBHelper.queryDocs(Collections.STUDENTS, [
            ['universityEmail', '==', universityEmail]
        ]);

        // Remove passwords from response
        const students = allStudents.map(student => {
            const { password, ...studentData } = student;
            return studentData;
        });

        res.json({
            universityEmail,
            studentCount: students.length,
            students
        });
    } catch (error) {
        console.error('Get university students error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// ===============================================
// STUDENT SUPPORT TICKET SYSTEM (GET VERSION)
// ===============================================

// API 9: Create Ticket (GET)
router.get("/ticket/create", async (req, res) => {
    try {
        const { studentEmail, accountEmail, problem } = req.query;

        if (!studentEmail || !accountEmail || !problem) {
            return res.status(400).json({
                error: "studentEmail, accountEmail and problem are required"
            });
        }

        // Validate student exists
        const student = await readStudent(studentEmail);
        if (!student) {
            return res.status(404).json({
                error: "Student not found"
            });
        }

        // Validate department account exists and belongs to the same university
        const account = await readAccount(accountEmail);
        if (!account) {
            return res.status(404).json({
                error: "Department account not found"
            });
        }

        if (account.universityEmail !== student.universityEmail) {
            return res.status(403).json({
                error: "This department does not belong to your university"
            });
        }

        // Generate unique ticket ID
        const ticketId =
            "ticket_" +
            Date.now() +
            "_" +
            Math.random().toString(36).substring(2, 10);

        const ticket = {
            ticketId,
            studentEmail,
            accountEmail,
            universityEmail: student.universityEmail,
            problem,
            status: "pending",
            solution: "",
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };

        await writeTicket(ticketId, ticket);

        res.status(201).json({
            message: "Ticket created successfully",
            ticket
        });
    } catch (error) {
        console.error("Create ticket error:", error);
        res.status(500).json({ error: "Internal server error" });
    }
});

// API 10: Get All Tickets for a Student (GET)
router.get("/ticket/list/:email", async (req, res) => {
    try {
        const { email } = req.params;

        const student = await readStudent(email);
        if (!student) {
            return res.status(404).json({
                error: "Student not found"
            });
        }

        const tickets = await getTicketsByEmail(email);

        res.json({
            studentEmail: email,
            totalTickets: tickets.length,
            tickets
        });
    } catch (error) {
        console.error("Get tickets error:", error);
        res.status(500).json({ error: "Internal server error" });
    }
});

// API 11: Delete Student (GET)
router.get('/delete', async (req, res) => {
    try {
        const { email } = req.query;

        if (!email) {
            return res.status(400).json({ error: 'email is required' });
        }

        const student = await readStudent(email);
        if (!student) {
            return res.status(404).json({ error: 'Student not found' });
        }

        // Delete student document
        const sanitizedEmail = MongoDBHelper.sanitizeEmail(email);
        await MongoDBHelper.deleteDoc(Collections.STUDENTS, sanitizedEmail);

        // Delete any pending registration for this email
        const pendingRegistrations = await readPendingStudentRegistrations();
        const filtered = pendingRegistrations.filter(reg => reg.email !== email);
        await writePendingStudentRegistrations(filtered);

        res.json({
            message: 'Student deleted successfully',
            studentEmail: email
        });
    } catch (error) {
        console.error('Delete student error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// API 12: Toggle Student Active Status (GET)
router.get('/toggle-status', async (req, res) => {
    try {
        const { email } = req.query;

        if (!email) {
            return res.status(400).json({ error: 'email is required' });
        }

        const student = await readStudent(email);
        if (!student) {
            return res.status(404).json({ error: 'Student not found' });
        }

        // Toggle status
        student.isActive = !student.isActive;
        student.updatedAt = new Date().toISOString();

        // Save updated data
        await writeStudent(email, student);

        res.json({
            message: `Student ${student.isActive ? 'activated' : 'deactivated'} successfully`,
            studentEmail: email,
            isActive: student.isActive
        });
    } catch (error) {
        console.error('Toggle student status error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});


// API 13: Delete Ticket by Student Email and Ticket ID (GET)
router.get('/ticket/delete', async (req, res) => {
    try {
        const { studentEmail, ticketId } = req.query;

        // Validation
        if (!studentEmail || !ticketId) {
            return res.status(400).json({
                error: 'studentEmail and ticketId are required'
            });
        }

        // Validate student exists
        const student = await readStudent(studentEmail);
        if (!student) {
            return res.status(404).json({
                error: 'Student not found'
            });
        }

        // Check if ticket exists
        const ticket = await MongoDBHelper.getDoc(Collections.TICKETS, ticketId);
        if (!ticket) {
            return res.status(404).json({
                error: 'Ticket not found'
            });
        }

        // Verify the ticket belongs to the specified student
        if (ticket.studentEmail !== studentEmail) {
            return res.status(403).json({
                error: 'This ticket does not belong to the specified student'
            });
        }

        // Delete the ticket
        await MongoDBHelper.deleteDoc(Collections.TICKETS, ticketId);

        res.json({
            message: 'Ticket deleted successfully',
            ticketId,
            studentEmail,
            deletedAt: new Date().toISOString()
        });

    } catch (error) {
        console.error('Delete ticket error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});


// API 14: Add Feedback to Accessible Account (GET)
router.get('/feedback/add', async (req, res) => {
    try {
        const { studentEmail, accountEmail, rating, feedbackText } = req.query;

        // Validation
        if (!studentEmail || !accountEmail || !rating || !feedbackText) {
            return res.status(400).json({
                error: 'studentEmail, accountEmail, rating, and feedbackText are required'
            });
        }

        // Convert rating to number
        const ratingNum = parseInt(rating);
        if (isNaN(ratingNum) || ratingNum < 1 || ratingNum > 5) {
            return res.status(400).json({
                error: 'rating must be a number between 1 and 5'
            });
        }

        // Validate student exists
        const student = await readStudent(studentEmail);
        if (!student) {
            return res.status(404).json({
                error: 'Student not found'
            });
        }

        // Check if the account is accessible to the student
        const isAccountAccessible = student.accessibleStores.some(
            store => store.accountEmail === accountEmail
        );

        if (!isAccountAccessible) {
            return res.status(403).json({
                error: 'This account is not accessible to the student'
            });
        }

        // Validate account exists
        const account = await readAccount(accountEmail);
        if (!account) {
            return res.status(404).json({
                error: 'Account not found'
            });
        }

        // Generate unique feedback ID
        const feedbackId = `feedback_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

        // Create feedback object
        const feedback = {
            feedbackId,
            studentEmail,
            studentName: student.name,
            accountEmail,
            accountName: account.accountName,
            rating: ratingNum,
            feedbackText,
            universityEmail: student.universityEmail,
            createdAt: new Date().toISOString()
        };

        // Save feedback to account's file
        if (!account.feedbacks) {
            account.feedbacks = [];
        }
        account.feedbacks.push(feedback);
        account.updatedAt = new Date().toISOString();

        // Save updated account data
        await writeAccount(accountEmail, account);

        res.status(201).json({
            message: 'Feedback submitted successfully',
            feedback: {
                feedbackId,
                studentEmail,
                accountEmail,
                rating: ratingNum,
                feedbackText,
                createdAt: feedback.createdAt
            }
        });

    } catch (error) {
        console.error('Add feedback error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Helper: Write account data using MongoDB
const writeAccount = async (email, accountData) => {
    await MongoDBHelper.setDoc(Collections.ACCOUNTS, email, accountData, true);
};


module.exports = router;